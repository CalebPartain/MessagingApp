#pragma once
namespace PNet
{
	enum PResult
	{
		P_Success,
		P_NotYetImplemented
	};
};

