#pragma once
namespace PNet
{
	enum IPVersion
	{
		IPv4,
		IPv6,
		UNKNOWN
	};
};