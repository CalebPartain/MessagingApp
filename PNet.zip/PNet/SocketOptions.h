#pragma once
namespace PNet
{
	enum SocketOption
	{
		TCP_NoDelay,	//True = disable nagles algo

	};
}