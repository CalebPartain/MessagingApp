//Server Code
#include "PNet\IncludeMe.h"
#include <iostream>


int main()
{

	if (PNet::Network::Initialize())
	{
		std::cout << "Winsock api successfully initialized." << std::endl;
		PNet::Socket socket;
		if (socket.Create() == PNet::PResult::P_Success)
		{
			std::cout << "Socket successfully created." << std::endl;
			if (socket.Listen(PNet::IPEndpoint("127.0.0.1", 4790)) == PNet::PResult::P_Success)
			{
				std::cout << "Socket Successfully listening on port 4790." << std::endl;
				PNet::Socket newConnection;
				if (socket.Accept(newConnection) == PNet::PResult::P_Success)
				{
					std::cout << "New connection accepted." << std::endl;
					char buffer[256];
					int bytesReceived = 0;
					int result = PNet::PResult::P_Success;
					while (true) {
						result = socket.Recv(buffer, 256, bytesReceived);
						//if (result != PNet::PResult::P_Success)
							//break;
						std::cout << buffer << std::endl;
						Sleep(500);
					}
					newConnection.Close();
				}
				else
				{
					std::cerr << "Failed to accept new connection." << std::endl;
				}

			}
			else
			{
				std::cerr << "Failed to listend on port 4790." << std::endl;
			}
			socket.Close();

		}
		else
		{
			std::cerr << "Socket failed to be created." << std::endl;
		}
	}
	PNet::Network::Shutdown();
	system("pause");
	return 0;
}